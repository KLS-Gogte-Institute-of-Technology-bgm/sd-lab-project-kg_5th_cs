<?php
$username = filter_input(INPUT_POST, 'username');
$email = filter_input(INPUT_POST, 'email');
$coverage_amt = filter_input(INPUT_POST, 'coverage_amt');
$gender = filter_input(INPUT_POST, 'gender');
$phone = filter_input(INPUT_POST, 'phone');

if (!empty($username)){
if (!empty($email)){
if (!empty($coverage_amt)){
if (!empty($gender)){
if (!empty($phone)){
$host = "localhost";
$dbusername = "root";
$dbemail = "";
$dbcoverage_amt = "";
$dbgender = "";
$dbphone = "";
$dbname = "LifeInsurance";//add database name
// Create connection
$conn = new mysqli ($host, $dbusername, $dbemail, $dbcoverage_amt, $dbgender, $dbphone, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO LIQ (username, email, coverage_amt, gender, phone)
values ('$username','$email''$coverage_amt','$gender','$phone')";
if ($conn->query($sql)){

}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
	echo "phone should not be empty";
die();
}
}
else{
	echo "gender should not be empty";
die();
}
}
else{
	echo "coverage_amt should not be empty";
die();
}
}
else{
	echo "email should not be empty";
die();
}
}
else{
echo "Username should not be empty";
die();
}
?>